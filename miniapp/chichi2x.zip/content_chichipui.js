// ちちぷいの投稿ページから投稿情報を抽出する。
// popup.js から chrome.scripting.executeScript({files:[...]}) で注入され、
// 最後に評価される式（IIFEの戻り値）が result として呼び出し元へ返る。
(() => {
  const collapse = (s) => (s || "").replace(/\s+/g, " ").trim();

  // タイトル: h1 のテキスト
  const titleEl = document.querySelector("h1");
  const title = collapse(titleEl && titleEl.textContent);

  // コメント: div.image-posts-detail__caption（無い投稿もある / 最大500字）
  const captionEl = document.querySelector("div.image-posts-detail__caption");
  let comment = "";
  if (captionEl) {
    comment = (captionEl.innerText || captionEl.textContent || "").trim();
    if (comment.length > 500) comment = comment.slice(0, 500);
  }

  // 画像URL: a[href*="post_images/originals"] を出現順に収集し、
  // クエリを除去 → 重複除去（出現順維持）
  const anchors = Array.from(document.querySelectorAll('a[href*="post_images/originals"]'));
  const seen = new Set();
  const images = [];
  for (const a of anchors) {
    let href = a.href || a.getAttribute("href");
    if (!href) continue;
    href = href.split("?")[0];
    if (!seen.has(href)) {
      seen.add(href);
      images.push(href);
    }
  }

  // R18判定: ちちぷいの投稿ページが持つ投稿単位の確実なmeta信号を見る。
  // 1) <meta name="rating" content="adult">（R18投稿に付く年齢レーティング）
  // 2) og:image が R18 用プレースホルダ（.../ogp/R18....jpeg）
  const isR18 = (() => {
    const rating = document.querySelector('meta[name="rating"]');
    if (rating && /adult/i.test(rating.getAttribute("content") || "")) return true;

    const og = document.querySelector('meta[property="og:image"]');
    if (og && /\/ogp\/R18[.\/]/i.test(og.getAttribute("content") || "")) return true;

    return false;
  })();

  return { title, comment, images, pageUrl: location.href, isR18 };
})();
