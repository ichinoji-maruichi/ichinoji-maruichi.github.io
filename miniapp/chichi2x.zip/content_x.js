"use strict";

// x.com 上で動作。background が保存した pendingAttach（画像データ）を拾い、
// 投稿画面のロードを待って画像を自動添付する。自動投稿は一切しない。
(() => {
  const KEY = "pendingAttach";
  const STALE_MS = 2 * 60 * 1000;
  const POLL_MS = 500;
  const TIMEOUT_MS = 20 * 1000;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function main() {
    let data;
    try {
      data = (await chrome.storage.local.get(KEY))[KEY];
    } catch (e) {
      return; // 拡張コンテキスト無効など
    }
    if (!data || !data.ts || Date.now() - data.ts > STALE_MS) {
      if (data) await safeRemove();
      return;
    }

    // 二重添付防止のため、拾った時点で消す
    await safeRemove();

    const images = Array.isArray(data.images) ? data.images : [];

    if (images.length === 0) {
      if (data.failed > 0) {
        showToast(`画像の取得に失敗しました（${data.failed}/${data.total}）。テキストのみで開きました。`);
      }
      return;
    }

    const files = [];
    for (const img of images) {
      try {
        files.push(dataUrlToFile(img.dataUrl, img.name, img.type));
      } catch (e) {
        console.warn("[chichipui-x] File変換失敗:", e);
      }
    }
    if (files.length === 0) {
      showToast("画像の変換に失敗しました。手動で添付してください。");
      return;
    }

    const ok = await attachWithRetry(files);

    if (data.failed > 0) {
      showToast(`一部の画像取得に失敗（${data.failed}/${data.total}）。${files.length}枚を添付しました。`);
    } else if (!ok) {
      showToast("画像の自動添付に失敗しました。手動で添付してください。");
    }
  }

  async function safeRemove() {
    try { await chrome.storage.local.remove(KEY); } catch (e) { /* noop */ }
  }

  // ---- 添付本体 ----
  async function attachWithRetry(files) {
    const deadline = Date.now() + TIMEOUT_MS;
    while (Date.now() < deadline) {
      const input = findFileInput();
      if (input) {
        if (setFilesOnInput(input, files)) return true;
      }
      await sleep(POLL_MS);
    }
    // フォールバック: 投稿欄への paste 注入
    return tryPaste(files);
  }

  function findFileInput() {
    const selectors = [
      'input[type="file"][data-testid="fileInput"]',
      'input[data-testid="fileInput"]',
      'input[type="file"][accept*="image"]',
      'input[type="file"][multiple]',
      'input[type="file"]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function setFilesOnInput(input, files) {
    try {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      input.files = dt.files;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (e) {
      console.warn("[chichipui-x] file input へのセット失敗:", e);
      return false;
    }
  }

  function tryPaste(files) {
    const box =
      document.querySelector('[data-testid="tweetTextarea_0"]') ||
      document.querySelector('div[role="textbox"][contenteditable="true"]') ||
      document.querySelector('div[contenteditable="true"]');
    if (!box) return false;
    try {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      box.focus();
      const evt = new ClipboardEvent("paste", { bubbles: true, cancelable: true });
      // 一部環境では constructor 経由で clipboardData をセットできないため上書き
      try {
        Object.defineProperty(evt, "clipboardData", { value: dt });
      } catch (e) { /* readonly の場合はそのまま */ }
      box.dispatchEvent(evt);
      return true;
    } catch (e) {
      console.warn("[chichipui-x] paste フォールバック失敗:", e);
      return false;
    }
  }

  function dataUrlToFile(dataUrl, name, type) {
    const comma = dataUrl.indexOf(",");
    const meta = dataUrl.slice(0, comma);
    const b64 = dataUrl.slice(comma + 1);
    const mime = type || (meta.match(/data:(.*?);/) || [])[1] || "image/png";
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new File([arr], name || "image.png", { type: mime });
  }

  // ---- トースト ----
  function showToast(message) {
    try {
      const el = document.createElement("div");
      el.textContent = message;
      Object.assign(el.style, {
        position: "fixed",
        top: "16px",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: "999999",
        maxWidth: "90vw",
        padding: "12px 18px",
        background: "rgba(29,155,240,0.97)",
        color: "#fff",
        fontSize: "14px",
        fontWeight: "700",
        borderRadius: "10px",
        boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
        fontFamily: "system-ui, sans-serif",
      });
      document.documentElement.appendChild(el);
      setTimeout(() => el.remove(), 8000);
    } catch (e) { /* noop */ }
  }

  main();
})();
