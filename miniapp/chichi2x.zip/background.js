"use strict";

// popup からの依頼を受け、対象画像を fetch（host_permissions でCORS回避）→
// base64 化して chrome.storage.local に保存し、X の投稿画面を新規タブで開く。
// 画像データは content_x.js が拾って自動添付する。

const STALE_MS = 2 * 60 * 1000; // pendingAttach の有効期限

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "openXPost") {
    handleOpenXPost(msg).then(sendResponse).catch((e) => {
      sendResponse({ ok: false, error: String(e), attached: 0, failed: 0, total: 0 });
    });
    return true; // 非同期レスポンス
  }
  return false;
});

async function handleOpenXPost({ text, imageUrls }) {
  const urls = Array.isArray(imageUrls) ? imageUrls : [];
  const images = [];
  let failed = 0;

  for (const url of urls) {
    try {
      const img = await fetchImage(url);
      images.push(img);
    } catch (e) {
      failed++;
      console.warn("[chichipui-x] 画像取得失敗:", url, e);
    }
  }

  await chrome.storage.local.set({
    pendingAttach: {
      images,
      failed,
      total: urls.length,
      ts: Date.now(),
    },
  });

  const intentUrl = "https://x.com/intent/post?text=" + encodeURIComponent(text || "");
  await chrome.tabs.create({ url: intentUrl });

  return { ok: true, attached: images.length, failed, total: urls.length };
}

async function fetchImage(url) {
  const res = await fetch(url, { credentials: "omit" });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const blob = await res.blob();
  const type = blob.type && blob.type.startsWith("image/") ? blob.type : guessType(url);
  const dataUrl = "data:" + type + ";base64," + arrayBufferToBase64(await blob.arrayBuffer());
  return { dataUrl, name: filenameFromUrl(url, type), type };
}

function filenameFromUrl(url, type) {
  let base = url.split("/").pop().split("?")[0] || "image";
  if (!/\.[a-zA-Z0-9]+$/.test(base)) {
    const ext = (type.split("/")[1] || "png").replace("jpeg", "jpg");
    base += "." + ext;
  }
  return base;
}

function guessType(url) {
  const m = url.toLowerCase().match(/\.(png|jpe?g|gif|webp)(?:$|\?)/);
  if (!m) return "image/png";
  const ext = m[1] === "jpg" ? "jpeg" : m[1];
  return "image/" + ext;
}

function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// 古い pendingAttach が残っていたら起動時に掃除
chrome.runtime.onStartup.addListener(clearStale);
chrome.runtime.onInstalled.addListener(clearStale);
async function clearStale() {
  const { pendingAttach } = await chrome.storage.local.get("pendingAttach");
  if (pendingAttach && Date.now() - pendingAttach.ts > STALE_MS) {
    await chrome.storage.local.remove("pendingAttach");
  }
}
