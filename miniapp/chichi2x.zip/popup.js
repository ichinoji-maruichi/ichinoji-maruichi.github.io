"use strict";

const DEFAULTS = { hashtags: "#AIイラスト #AIart", appendUrl: false, multiMode: "first" };
const POST_RE = /^https:\/\/www\.chichi-pui\.com\/posts\/[0-9a-fA-F-]+\/?/;
const MAX_IMAGES = 4;
const THUMB_POLICY = "?impolicy=carousel-thumbnail";

// --- DOM refs ---
const $ = (id) => document.getElementById(id);
const panels = { main: $("main"), settings: $("settings"), imageSelect: $("imageSelect") };

function showPanel(name) {
  for (const key of Object.keys(panels)) panels[key].classList.toggle("hidden", key !== name);
}

function setStatus(msg, isErr = false) {
  const el = $("mainStatus");
  el.textContent = msg || "";
  el.classList.toggle("err", !!isErr);
}

// --- settings ---
async function getSettings() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...s };
}

async function loadSettingsIntoForm() {
  const s = await getSettings();
  $("hashtags").value = s.hashtags;
  $("appendUrl").checked = s.appendUrl;
  const radio = document.querySelector(`input[name="multiMode"][value="${s.multiMode}"]`)
    || $("mode-first");
  radio.checked = true;
}

function wireSettingsAutoSave() {
  $("hashtags").addEventListener("input", () => {
    chrome.storage.sync.set({ hashtags: $("hashtags").value });
  });
  $("appendUrl").addEventListener("change", () => {
    chrome.storage.sync.set({ appendUrl: $("appendUrl").checked });
  });
  for (const r of document.querySelectorAll('input[name="multiMode"]')) {
    r.addEventListener("change", () => {
      if (r.checked) chrome.storage.sync.set({ multiMode: r.value });
    });
  }
}

// --- helpers ---
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function buildText(data, settings) {
  const titleLine = data.title && data.title.trim() ? `【${data.title.trim()}】` : "";
  // タイトルは【】で囲み、タイトルとコメントの間に空行を1つ挟む
  const head = [titleLine, data.comment].filter((s) => s && s.trim().length).join("\n\n");

  let tags = settings.hashtags ? settings.hashtags.trim() : "";
  // URL末尾追加がオンなら #ちちぷい を付与（重複時は付けない）
  if (settings.appendUrl && !/(^|\s)#ちちぷい($|\s)/.test(tags)) {
    tags = tags ? `${tags} #ちちぷい` : "#ちちぷい";
  }

  const tail = [];
  if (tags) tail.push(tags);
  // R18ページのときはURLの頭に🔞を付ける
  if (settings.appendUrl && data.pageUrl) {
    tail.push((data.isR18 ? "🔞" : "") + data.pageUrl);
  }

  return tail.length ? `${head}\n\n${tail.join("\n")}` : head;
}

function resolveImages(images, settings) {
  if (!images || images.length === 0) return { need: false, images: [] };
  if (settings.multiMode === "upto4") return { need: false, images: images.slice(0, MAX_IMAGES) };
  if (settings.multiMode === "select" && images.length > 1) return { need: true, images };
  // "first", or "select" with a single image
  return { need: false, images: images.slice(0, 1) };
}

// --- main share flow ---
async function onShare() {
  const tab = await getActiveTab();
  if (!tab || !POST_RE.test(tab.url || "")) {
    setStatus("ちちぷいの投稿ページで開いてください", true);
    return;
  }
  $("shareBtn").disabled = true;
  setStatus("投稿情報を取得中…");

  let data;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content_chichipui.js"],
    });
    data = results && results[0] && results[0].result;
  } catch (e) {
    setStatus("ページからの情報取得に失敗しました", true);
    $("shareBtn").disabled = false;
    return;
  }

  if (!data || !data.title) {
    setStatus("投稿情報を取得できませんでした", true);
    $("shareBtn").disabled = false;
    return;
  }

  const settings = await getSettings();
  const text = buildText(data, settings);
  const resolved = resolveImages(data.images, settings);

  if (resolved.need) {
    showImageSelect(data.images, text);
    $("shareBtn").disabled = false;
    return;
  }
  await proceed(text, resolved.images);
}

async function proceed(text, imageUrls) {
  setStatus(imageUrls.length ? `画像を取得中… (${imageUrls.length}枚)` : "Xを開いています…");
  try {
    const res = await chrome.runtime.sendMessage({ type: "openXPost", text, imageUrls });
    if (res && res.failed > 0) {
      setStatus(`Xを開きました。画像 ${res.attached}/${res.total} 枚取得（一部失敗）`, true);
    } else {
      setStatus("Xを開きました。");
    }
  } catch (e) {
    setStatus("Xを開く処理に失敗しました", true);
  } finally {
    $("shareBtn").disabled = false;
  }
}

// --- image select UI ---
function showImageSelect(images, text) {
  const container = $("thumbs");
  container.innerHTML = "";
  const selected = new Set(images.slice(0, MAX_IMAGES).map((_, i) => i));

  const renderNumbers = () => {
    const order = [...selected];
    images.forEach((_, i) => {
      const el = container.children[i];
      if (!el) return;
      const isSel = selected.has(i);
      el.classList.toggle("selected", isSel);
      const num = el.querySelector(".num");
      num.textContent = isSel ? String(order.indexOf(i) + 1) : "";
    });
    $("selectHint").textContent =
      `${selected.size}/${MAX_IMAGES} 枚選択中（最大4枚まで）`;
  };

  images.forEach((url, i) => {
    const div = document.createElement("div");
    div.className = "thumb";
    const img = document.createElement("img");
    img.src = url + THUMB_POLICY;
    img.loading = "lazy";
    img.alt = `画像${i + 1}`;
    img.addEventListener("error", () => { img.src = url; }); // サムネ失敗時は原寸
    const num = document.createElement("span");
    num.className = "num";
    div.appendChild(img);
    div.appendChild(num);
    div.addEventListener("click", () => {
      if (selected.has(i)) {
        selected.delete(i);
      } else {
        if (selected.size >= MAX_IMAGES) {
          $("selectHint").textContent = `画像は最大${MAX_IMAGES}枚までです`;
          return;
        }
        selected.add(i);
      }
      renderNumbers();
    });
    container.appendChild(div);
  });

  renderNumbers();

  $("confirmBtn").onclick = async () => {
    if (selected.size === 0) {
      $("selectHint").textContent = "1枚以上選択してください";
      return;
    }
    const picked = [...selected].sort((a, b) => a - b).map((i) => images[i]);
    showPanel("main");
    await proceed(text, picked);
  };
  $("cancelSelect").onclick = () => {
    showPanel("main");
    setStatus("");
  };

  showPanel("imageSelect");
}

// --- init ---
async function init() {
  await loadSettingsIntoForm();
  wireSettingsAutoSave();

  $("shareBtn").addEventListener("click", onShare);
  $("toSettings").addEventListener("click", () => showPanel("settings"));
  $("toMain").addEventListener("click", () => showPanel("main"));

  // メイン画面ボタンの有効/無効判定
  const tab = await getActiveTab();
  if (!tab || !POST_RE.test(tab.url || "")) {
    $("shareBtn").disabled = true;
    setStatus("ちちぷいの投稿ページで開いてください");
  }
}

init();
